Install the requirements: pip install -r requirements.txt
To run the summarization agent go run:  streamlit run summarizerAgent.py